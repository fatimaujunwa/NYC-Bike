# --------------------------------------------------------
#
# PYTHON PROGRAM DEFINITION
#
# The knowledge a computer has of Python can be specified in 3 levels:
# (1) Prelude knowledge --> The computer has it by default.
# (2) Borrowed knowledge --> The computer gets this knowledge from 3rd party libraries defined by others
#                            (but imported by us in this program).
# (3) Generated knowledge --> The computer gets this knowledge from the new functions defined by us in this program.
#
# When launching in a terminal the command:
# user:~$ python3 this_file.py
# our computer first processes this PYTHON PROGRAM DEFINITION section of the file.
# On it, our computer enhances its Python knowledge from levels (2) and (3) with the imports and new functions
# defined in the program. However, it still does not execute anything.
#
# --------------------------------------------------------


# --------------------------------------------------------
# IMPORTS
# --------------------------------------------------------
import neo4j
import os
import codecs
import sys


# ------------------------------------------
# FUNCTION 01 - read_cypher_query
# ------------------------------------------
def read_cypher_query(my_cypher_query_file):
    # 1. We create the output variable
    res = ""

    # 2. We open the file for reading
    my_input_stream = codecs.open(my_cypher_query_file, "r", encoding="utf-8")

    # 3. We read the query from the file
    for line in my_input_stream:
        res = res + line

    # 4. We close the file
    my_input_stream.close()

    # 5. We return res
    return res


# ------------------------------------------
# FUNCTION 02 - print_record_list
# ------------------------------------------
def print_record_list(record_list):
    # 1. We print a header
    print("---------------------")
    print("---               ---")
    print("---   RECORDS     ---")
    print("---               ---")
    print("---------------------")

    # 2. We traverse the documents so as to print them
    index = 0
    for neo4j_record in record_list:
        # 2.1. We print the info of the document
        print("---------------------------------")
        print("--- RECORD ", index, "INFO    ---")
        print("---------------------------------")
        print(neo4j_record)

        # 2.2. We increase the index
        index = index + 1

# ----------------------------------------------------
# FUNCTION 03 - store_result
# ----------------------------------------------------
def store_result(record_list, output_file_name):
    # 1. We open the file for reading
    my_output_stream = codecs.open(output_file_name, "w", encoding="utf-8")

    # 2. We traverse the documents of the collection
    for neo4j_record in record_list:
        # 2.1. We convert the record to a String format
        my_str = str(neo4j_record) + "\n"

        # 2.2. We write the String to the file
        my_output_stream.write(my_str)

    # 3. We close the file
    my_output_stream.close()


# ------------------------------------------
# FUNCTION 04 - my_main
# ------------------------------------------
def my_main(server_name,
            my_user,
            my_password,
            my_database
           ):

    # 1. We create the neo4j driver
    neo4j_driver = neo4j.GraphDatabase.driver(server_name, auth=(my_user, my_password))

    # 2. We create the neo4j_session
    neo4j_session = None
    if (my_database == None):
        neo4j_session = neo4j_driver.session()
    else:
        neo4j_session = neo4j_driver.session(database=my_database)

    # 3. We design the query
    my_query = read_cypher_query("my_code/A01_ex11/A01_ex11_my_query_file.cypher")

    # 4. We trigger my_query
    record_list = list(neo4j_session.run(my_query))

    # 5. We print the record_list by console
    print_record_list(record_list)

    # 6. We save the result to a file
    store_result(record_list, output_file_name)

    # 7. We disconnect from mongodb
    neo4j_driver.close()


# ---------------------------------------------------------------
#           PYTHON EXECUTION
# This is the main entry point to the execution of our program.
# It provides a call to the 'main function' defined in our
# Python program, making the Python interpreter to trigger
# its execution.
# ---------------------------------------------------------------
if __name__ == '__main__':
    # 1. We get the input values
    output_file_name = "my_results/Student_Solutions/A01_ex11/result.txt"

    # 2. We get the credentials
    sys.path.append("../../my_credentials/")
    import my_credentials

    (local_False_Aura_True,
     my_database,
     my_user,
     my_password,
     server_name
     ) = my_credentials.my_Neo4j_credentials()

    # 3. We call to my_main
    my_main(server_name,
            my_user,
            my_password,
            my_database
           )
