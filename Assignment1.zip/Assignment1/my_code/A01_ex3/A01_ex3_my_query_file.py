# --------------------------------------------------------
#
# PYTHON PROGRAM DEFINITION
#
# The knowledge a computer has of Python can be specified in 3 levels:
# (1) Prelude knowledge --> The computer has it by default.
# (2) Borrowed knowledge --> The computer gets this knowledge from 3rd party libraries defined by others
#                            (but imported by us in this program).
# (3) Generated knowledge --> The computer gets this knowledge from the new functions defined by us in this program.
#
# When launching in a terminal the command:
# user:~$ python3 this_file.py
# our computer first processes this PYTHON PROGRAM DEFINITION section of the file.
# On it, our computer enhances its Python knowledge from levels (2) and (3) with the imports and new functions
# defined in the program. However, it still does not execute anything.
#
# --------------------------------------------------------



# ------------------------------------------------------------------------
# FUNCTION A01_ex3_my_query
# ------------------------------------------------------------------------
def A01_ex3_my_query(mongodb_collection, my_time, my_zipcode):
    # 1. We create the output variable (list of documents from the mongo_db collection returned by the query)
    res = None

    # 2. We create a query pipeline
    my_query = [
        # 3.1. We use a 'match' command to filter documents by the given time and zipcode
        {
            "$match": {
                "time": my_time,
                "zipcode": my_zipcode
            }
        },
        # 3.2. We use a 'sort' command to sort them by decreasing amount of 'available_bikes'
        {
            "$sort": {
                "available_bikes": -1
            }
        },
        # 3.3. We use a 'project' command to select only the required fields: station_name and available_bikes
        {
            "$project": {
                "_id": 0,  # Excludes the _id field from the results
                "station_name": 1,
                "available_bikes": 1
            }
        }
    ]

    # 4. We trigger our query pipeline
    res = list(mongodb_collection.aggregate(my_query))

    # 5. We return res
    return res


