# --------------------------------------------------------
#
# PYTHON PROGRAM DEFINITION
#
# The knowledge a computer has of Python can be specified in 3 levels:
# (1) Prelude knowledge --> The computer has it by default.
# (2) Borrowed knowledge --> The computer gets this knowledge from 3rd party libraries defined by others
#                            (but imported by us in this program).
# (3) Generated knowledge --> The computer gets this knowledge from the new functions defined by us in this program.
#
# When launching in a terminal the command:
# user:~$ python3 this_file.py
# our computer first processes this PYTHON PROGRAM DEFINITION section of the file.
# On it, our computer enhances its Python knowledge from levels (2) and (3) with the imports and new functions
# defined in the program. However, it still does not execute anything.
#
# --------------------------------------------------------


# --------------------------------------------------------
# IMPORTS
# --------------------------------------------------------
import os
import pymongo
import json
import codecs
import sys

import A01_ex4_my_query_file


# --------------------------------------------------------
# FUNCTION 01 - mongoDB_connect
# --------------------------------------------------------
def mongoDB_connect(local_False_Atlas_True,
                    server_name,
                    my_database,
                    my_collection
                   ):

    # 1. We create the output variable
    res = ()

    # 1.1. We output the mongodb_client
    mongodb_client = None

    # 1.2. We output mongodb_database (the database we connect to)
    mongodb_database = None

    # 1.3. We output mongodb_collection (the collection we connect to)
    mongodb_collection = None

    # 2. We assign mongodb_client
    if (local_False_Atlas_True == False):
        mongodb_client = pymongo.MongoClient()
    else:
        mongodb_client = pymongo.MongoClient(server_name)

    # 3. We assign mongodb_database
    mongodb_database = mongodb_client.get_database(my_database)

    # 4. We assign mongodb_collection
    mongodb_collection = mongodb_database.get_collection(my_collection)

    # 5. We assign res
    res = (mongodb_client, mongodb_database, mongodb_collection)

    # 6. We return res
    return res


# --------------------------------------------------------
# FUNCTION 02 - mongoDB_disconnect
# --------------------------------------------------------
def mongoDB_disconnect(mongodb_client):
    # 1. We close the connection with the MongoDB client
    mongodb_client.close()


# ------------------------------------------
# FUNCTION 03 - print_document_list
# ------------------------------------------
def print_document_list(document_list):
    # 1. We print a header
    print("---------------------")
    print("---               ---")
    print("---   DOCUMENTS   ---")
    print("---               ---")
    print("---------------------")

    # 2. We traverse the documents so as to print them
    index = 0
    for mongodb_document in document_list:
        # 2.1. We print the info of the document
        print("---------------------------------")
        print("--- DOCUMENT", index, "INFO   ---")
        print("---------------------------------")
        for key in mongodb_document:
            print(key, " : ", mongodb_document[key])

        # 2.2. We increase the index
        index = index + 1


# ----------------------------------------------------
# FUNCTION 04 - store_result
# ----------------------------------------------------
def store_result(mongodb_collection, output_file_name):
    # 1. We open the file for reading
    my_output_stream = codecs.open(output_file_name, "w", encoding="utf-8")

    # 2. We traverse the documents of the collection
    for my_dict in mongodb_collection:
        # 2.1. We delete the key '_id'
        if (("_id" in my_dict) and (str(type(my_dict["_id"])) == "<class \'bson.objectid.ObjectId\'>")):
            del my_dict["_id"]

        # 2.2. We convert the dict to a String format
        my_str = json.dumps(my_dict) + "\n"

        # 2.3. We write the String to the file
        my_output_stream.write(my_str)

    # 3. We close the file
    my_output_stream.close()


# ------------------------------------------
# FUNCTION 05 - my_main
# ------------------------------------------
def my_main(local_False_Atlas_True,
            server_name,
            my_database,
            my_collection,
            output_file_name
           ):

    # 1. We connect to mongodb
    (mongodb_client, mongodb_database, mongodb_collection) = mongoDB_connect(local_False_Atlas_True,
                                                                             server_name,
                                                                             my_database,
                                                                             my_collection
                                                                            )

    # 2. We trigger the query: Unwind the collection based on the sports liked
    document_list = A01_ex4_my_query_file.A01_ex4_my_query(mongodb_collection)


    # 3. We print the document_list by console
    print_document_list(document_list)

    # 4. We save the result to a file
    store_result(document_list, output_file_name)

    # 5. We disconnect from mongodb
    mongoDB_disconnect(mongodb_client)


# ---------------------------------------------------------------
#           PYTHON EXECUTION
# This is the main entry point to the execution of our program.
# It provides a call to the 'main function' defined in our
# Python program, making the Python interpreter to trigger
# its execution.
# ---------------------------------------------------------------
if __name__ == '__main__':
    # 1. We get the input arguments
    output_file_name = "my_results/Student_Solutions/A01_ex4/result.txt"

    # 2. We get the credentials
    sys.path.append("../../my_credentials/")
    import my_credentials

    (local_False_Atlas_True,
     my_database,
     my_collection,
     server_name
    ) = my_credentials.my_MongoDB_credentials()

    # 3. We call to my_main
    my_main(local_False_Atlas_True,
            server_name,
            my_database,
            my_collection,
            output_file_name
           )
