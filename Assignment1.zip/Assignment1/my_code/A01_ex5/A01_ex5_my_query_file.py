# --------------------------------------------------------
#
# PYTHON PROGRAM DEFINITION
#
# The knowledge a computer has of Python can be specified in 3 levels:
# (1) Prelude knowledge --> The computer has it by default.
# (2) Borrowed knowledge --> The computer gets this knowledge from 3rd party libraries defined by others
#                            (but imported by us in this program).
# (3) Generated knowledge --> The computer gets this knowledge from the new functions defined by us in this program.
#
# When launching in a terminal the command:
# user:~$ python3 this_file.py
# our computer first processes this PYTHON PROGRAM DEFINITION section of the file.
# On it, our computer enhances its Python knowledge from levels (2) and (3) with the imports and new functions
# defined in the program. However, it still does not execute anything.
#
# --------------------------------------------------------



# ------------------------------------------------------------------------
# FUNCTION A01_ex5_my_query
# ------------------------------------------------------------------------
def A01_ex5_my_query(mongodb_collection):
    # 1. We create the output variable (list of documents from the mongo_db collection returned by the query)
    res = None

    # 2. We create a query pipeline
    my_query = [
        # Group the documents by 'borough', and count the unique 'station_id's for each group
        {
            "$group": {
                "_id": "$borough",
                "num_stations": {"$addToSet": "$station_id"}
            }
        },
        # Add a stage to calculate the size of the unique 'station_id's set for each 'borough'
        {
            "$addFields": {
                "num_stations": {"$size": "$num_stations"}
            }
        },
        # Sort the results first by 'num_stations' in descending order, then by '_id' (borough name) in ascending order
        {
            "$sort": {
                "num_stations": -1,
                "_id": 1
            }
        },
        # Optionally, rename '_id' to 'borough' to match the expected output format
        {
            "$project": {
                "borough": "$_id",
                "num_stations": 1,
                "_id": 0
            }
        }
    ]

    # 4. We trigger our query pipeline
    res = list(mongodb_collection.aggregate(my_query))

    # 5. We return res
    return res
