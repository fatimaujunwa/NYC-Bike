# --------------------------------------------------------
#
# PYTHON PROGRAM DEFINITION
#
# The knowledge a computer has of Python can be specified in 3 levels:
# (1) Prelude knowledge --> The computer has it by default.
# (2) Borrowed knowledge --> The computer gets this knowledge from 3rd party libraries defined by others
#                            (but imported by us in this program).
# (3) Generated knowledge --> The computer gets this knowledge from the new functions defined by us in this program.
#
# When launching in a terminal the command:
# user:~$ python3 this_file.py
# our computer first processes this PYTHON PROGRAM DEFINITION section of the file.
# On it, our computer enhances its Python knowledge from levels (2) and (3) with the imports and new functions
# defined in the program. However, it still does not execute anything.
#
# --------------------------------------------------------



# ------------------------------------------------------------------------
# FUNCTION A01_ex6_my_query
# ------------------------------------------------------------------------
def A01_ex6_my_query(mongodb_collection, my_station_id, my_num_hours):
    # 1. We create the output variable (list of documents from the mongo_db collection returned by the query)
    res = None

    # 2. We create a query pipeline
    my_query = [
        # Filter documents by station_id and station_status
        {
            "$match": {
                "station_id": my_station_id,
                "station_status": "In Service"
            }
        },
        # Extract the hour from the time field
        {
            "$addFields": {
                "hour": {"$substr":[ "$time", 11,2]}
            }
        },
        # Group documents by hour, count total, and count where available_bikes = 0
        {
            "$group": {
                "_id": "$hour",
                "total_measurements": {"$sum": 1},
                "zero_bikes_measurements": {
                    "$sum": {
                        "$cond": [{"$eq": ["$available_bikes", 0]}, 1, 0]
                    }
                }
            }
        },
        # Calculate the percentage of zero_bikes_measurements
        {
            "$addFields": {
                "percentage": {
                   "$round":[
                       {
                            "$multiply": [{"$divide": ["$zero_bikes_measurements", "$total_measurements"]}, 100]
                       },2
                   ]
                }
            }
        },
        # Sort by percentage in decreasing order
        {
            "$sort": {"percentage": -1}
        },
        # Limit to top num_hours results
        {
            "$limit": my_num_hours
        },
        # Optionally, project results to match expected format
        {
            "$project": {
                "hour": "$_id",
                "percentage": 1,
                "total_measurements": 1,
                "zero_bikes_measurements": 1,
                "_id": 0
            }
        }
    ]

    # 8. We trigger our query pipeline
    res = list(mongodb_collection.aggregate(my_query))

    # 9. We return res
    return res
