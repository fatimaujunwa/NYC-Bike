# --------------------------------------------------------
#
# PYTHON PROGRAM DEFINITION
#
# The knowledge a computer has of Python can be specified in 3 levels:
# (1) Prelude knowledge --> The computer has it by default.
# (2) Borrowed knowledge --> The computer gets this knowledge from 3rd party libraries defined by others
#                            (but imported by us in this program).
# (3) Generated knowledge --> The computer gets this knowledge from the new functions defined by us in this program.
#
# When launching in a terminal the command:
# user:~$ python3 this_file.py
# our computer first processes this PYTHON PROGRAM DEFINITION section of the file.
# On it, our computer enhances its Python knowledge from levels (2) and (3) with the imports and new functions
# defined in the program. However, it still does not execute anything.
#
# --------------------------------------------------------


# --------------------------------------------------------
# IMPORTS
# --------------------------------------------------------
import os

print("Current Working Directory:", os.getcwd())
# ------------------------------------------
# FUNCTION my_MongoDB_credentials
# ------------------------------------------
def my_MongoDB_credentials():
    # 1. We create the output variable
    res = ()

    # 1.1. We output the local_False_Atlas_True
    #      --------- TO BE COMPLETED ----------
    #      e.g., local_False_Atlas_True = True
    #      ------------------------------------
    local_False_Atlas_True = True

    # 1.2. We output the database name
    #      --------- TO BE COMPLETED ----------
    #      e.g., my_database = "my_database"
    #      ------------------------------------
    my_database = "adb"

    # 1.3. We output the collection name
    #      --------- TO BE COMPLETED ----------
    #      e.g., my_database = "my_database"
    #      ------------------------------------
    my_collection = "newCollection"

    # 1.4. We output the server_name
    #      --------- LEAVE AS IT IS ----------
    server_name = ""
    #      ------------------------------------

    # 2. If using MongoDB Atlas, we compose the server_name
    if (local_False_Atlas_True == True):
        # 2.1. We use our user
        #      --------- TO BE COMPLETED ----------
        #      e.g., my_user = "myuser"
        #      ------------------------------------
        my_user = "16-ENG02-057f"

        # 2.2. We use our password
        #      --------- TO BE COMPLETED ----------
        #      e.g., my_user = "batman"
        #      ------------------------------------
        my_password = "16-ENG02-057f"

        # 2.3. We use the cluster we are connecting to
        #      --------- TO BE COMPLETED ----------
        #      e.g., my_user = "cluster0"
        #      ------------------------------------
        my_cluster = "cluster0"

        # 2.4. We use the name of the VM server in the cluster
        #      --------- TO BE COMPLETED ----------
        #      e.g., my_user = "czo9bfs"
        #      ------------------------------------
        vm_name = "rv1gqp8"

        # 2.5. We compose the server_name
        #      --------- LEAVE AS IT IS ----------
        server_name = "mongodb+srv://" + my_user + ":" + my_password + "@" + my_cluster + "." + vm_name + ".mongodb.net/" + my_database + "?retryWrites=true&w=majority"
        #      ------------------------------------

    # 3. We assign res
    res = (local_False_Atlas_True,
           my_database,
           my_collection,
           server_name
          )

    # 4. We return res
    return res


# ------------------------------------------
# FUNCTION my_Neo4j_credentials
# ------------------------------------------
def my_Neo4j_credentials():
    # 1. We create the output variable
    res = ()

    # 1.1. We output the local_False_Aura_True
    #      --------- TO BE COMPLETED ----------
    #      e.g., local_False_Aura_True = True
    #      ------------------------------------
    local_False_Aura_True = True

    # 1.2. We output the database name
    #      --------- LEAVE AS IT IS ----------
    #      e.g., my_database = "mydatabase"
    #      ------------------------------------
    my_database = "mydatabase"

    # 1.3. We output the user
    #      --------- LEAVE AS IT IS ----------
    #      e.g., my_user = "myuser"
    #      ------------------------------------
    my_user = "myuser"

    # 1.4. We output the password
    #      --------- TO BE COMPLETED ----------
    #      e.g., my_user = "batman"
    #      ------------------------------------
    my_password = os.getenv("O2b5wc6NJHocmjM8UlQdjTlzZxor2lMg4DSjpIUEo3A")

    # 1.5. We output the server_name
    #      --------- LEAVE AS IT IS ----------
    server_name = "bolt://localhost:7687"
    #      ------------------------------------

    # 2. If using Neo4j Aura, we compose the server_name
    if (local_False_Aura_True == True):
        # 2.1. We set the my_database
        #      --------- LEAVE AS IT IS ----------
        my_database = None
        #      ------------------------------------

        # 2.2. We set the user
        #      --------- LEAVE AS IT IS ----------
        #      e.g., my_user = "neo4j"
        #      ------------------------------------
        my_user = "neo4j"

        # 2.3. We output the password
        #      --------- TO BE COMPLETED ----------
        #      e.g., my_password = "A0b1CdEFG2hIjklMnoPQRSTU3v45x6Yz7_ABcdEFGh"
        #      ------------------------------------
        my_password = "O2b5wc6NJHocmjM8UlQdjTlzZxor2lMg4DSjpIUEo3A"

        # 2.4. We set our server_domain
        #      --------- TO BE COMPLETED ----------
        #      e.g., server_domain = "01ab34c5"
        #      ------------------------------------
        server_domain = "2a8fe298"

        # 2.5. We set our server_name
        #      --------- LEAVE AS IT IS ----------
        server_name = "bolt+s://" + str(server_domain) + ".databases.neo4j.io:7687"
        #      ------------------------------------

    # 3. We assign res
    res = (local_False_Aura_True,
           my_database,
           my_user,
           my_password,
           server_name
          )

    # 4. We return res
    return res
