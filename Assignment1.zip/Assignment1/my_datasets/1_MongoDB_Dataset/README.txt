
This folder contains the following files: 

-----------------------
FILE 1
-----------------------
stations_dataset.json
-----------------------
This is the dataset to be used in the assignment



-----------------------
FILE 2
-----------------------
MongoDB_load_dataset.py
-----------------------
This program uploads the dataset to MongoDB Atlas.
