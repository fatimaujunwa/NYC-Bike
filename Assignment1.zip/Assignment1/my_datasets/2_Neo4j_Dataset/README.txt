
This folder contains the following files: 

-----------------------
FILE 1
-----------------------
trips_dataset.csv
-----------------------
This is the dataset to be used in the assignment.



-----------------------
FILE 2
-----------------------
Neo4j_load_dataset.py
-----------------------
This Python program loads the dataset to Neo4j. 



-----------------------
FILES 3-12
-----------------------
command_0.cypher
command_1.cypher
command_2.cypher
command_3.cypher
command_4.cypher
command_5.cypher
command_6.cypher
command_7.cypher
command_8.cypher
command_9.cypher
-----------------------
This files are used by the Python program above. 
You do not need to need to do anything with them. 



 