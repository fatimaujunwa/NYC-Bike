import sys
import codecs

query = 1
# student_solutions_directory1 = "my_results/Student_Solutions/A01_ex1/results.txt"
my_dataset_file = "/Users/ujunwafatima/Downloads/A01/my_datasets/1_MongoDB_Dataset/stations_dataset.json"

my_input_stream_1 = codecs.open(my_dataset_file, "r", encoding="utf-8")


